create function st_geomfromgml(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_GeomFromGML($1, 0)
$$;

comment on function st_geomfromgml(text) is 'args: geomgml - Takes as input GML representation of geometry and outputs a PostGIS geometry object';

alter function st_geomfromgml(text) owner to postgres;

