create function st_geomcollfromwkb(bytea, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

alter function st_geomcollfromwkb(bytea, integer) owner to postgres;

