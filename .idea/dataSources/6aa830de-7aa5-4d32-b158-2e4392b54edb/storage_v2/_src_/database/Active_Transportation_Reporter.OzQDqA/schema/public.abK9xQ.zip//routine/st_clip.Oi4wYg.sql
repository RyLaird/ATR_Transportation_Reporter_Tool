create function st_clip(rast raster, geom geometry, crop boolean) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_Clip($1, NULL, $2, null::double precision[], $3)
$$;

alter function st_clip(raster, geometry, boolean) owner to postgres;

