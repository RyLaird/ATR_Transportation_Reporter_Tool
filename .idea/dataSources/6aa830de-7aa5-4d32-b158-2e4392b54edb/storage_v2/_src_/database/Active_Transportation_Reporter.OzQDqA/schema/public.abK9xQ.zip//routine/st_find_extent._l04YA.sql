create function st_find_extent(text, text, text) returns box2d
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Find_Extent', 'ST_FindExtent', '2.2.0');
    SELECT public.ST_FindExtent($1,$2,$3);
$$;

alter function st_find_extent(text, text, text) owner to postgres;

