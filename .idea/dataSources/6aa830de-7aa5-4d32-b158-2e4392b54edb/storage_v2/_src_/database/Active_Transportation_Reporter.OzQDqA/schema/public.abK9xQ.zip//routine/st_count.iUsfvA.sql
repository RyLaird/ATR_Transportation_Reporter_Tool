create function st_count(rast raster, exclude_nodata_value boolean) returns bigint
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_count($1, 1, $2, 1)
$$;

comment on function st_count(raster, boolean) is 'args: rast, exclude_nodata_value - Returns the number of pixels in a given band of a raster or raster coverage. If no band is specified defaults to band 1. If exclude_nodata_value is set to true, will only count pixels that are not equal to the nodata value.';

alter function st_count(raster, boolean) owner to postgres;

